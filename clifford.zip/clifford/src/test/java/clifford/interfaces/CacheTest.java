package clifford.interfaces;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import impl.CacheImpl;

import java.util.Arrays;

import org.junit.Test;

public class CacheTest {

	@Test
	public void test_cacheTest() {

		//	Given
		int cacheMaxSize = 3;
		Cache cache = new CacheImpl(cacheMaxSize);

		Object a = "A";
		Object b = "B";
		Object c = "C";
		Object d = "D";

		//	When
		//	Then
		cache.cacheItem(a, "a");
		assertEquals(1, cache.getView().size());

		cache.cacheItem(b, "b");
		assertEquals(2, cache.getView().size());

		cache.cacheItem(c, "c");
		assertEquals(3, cache.getView().size());

		cache.cacheItem(d, "d");
		assertEquals(3, cache.getView().size());

		boolean containsAll = cache.getValues().containsAll(Arrays.asList("B", "C", "D"));
		assertTrue(containsAll);

	}
}
