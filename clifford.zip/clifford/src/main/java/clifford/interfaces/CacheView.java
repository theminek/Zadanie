package clifford.interfaces;

public interface CacheView {

	CacheItem getItem(int index);//zwraca obiekt o podanym indeksie

	CacheItem getItem(String key);//zwraca obiekt o podanym kluczu

	int size();//zwraca wielkość Cache’a
}
