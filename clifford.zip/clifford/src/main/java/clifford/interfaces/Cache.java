package clifford.interfaces;

import java.util.Collection;

public interface Cache {

	CacheItem cacheItem(Object item, String key);//zapisuje obiekt w Cache’u

	//	Added additionaly for tests
	Collection<Object> getValues();

	CacheView getView();//zwraca “widok” na nasz Cache

	void invalidateCache();//czyści nasz Cache
}
