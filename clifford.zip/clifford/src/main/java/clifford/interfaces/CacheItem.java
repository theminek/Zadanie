package clifford.interfaces;

public interface CacheItem {

	String getKey(); // zwraca klucz obiektu

	Object getValue(); //zwraca obiekt zapisanych w Cache’u
}
