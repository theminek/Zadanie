package impl;

import clifford.interfaces.CacheItem;

/**
 * Example of Java "Immutable object", more info under link:
 *
 *	http://www.javapractices.com/topic/TopicAction.do?Id=29
 *
 */
public class CacheItemImpl implements CacheItem {

	private final String key;
	private final Object value;

	public CacheItemImpl(String key, Object value) {
		super();
		this.key = key;
		this.value = value;
	}

	@Override
	public String getKey() {
		return key;
	}

	@Override
	public Object getValue() {
		return value;
	}

}
