package impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import clifford.interfaces.Cache;
import clifford.interfaces.CacheItem;
import clifford.interfaces.CacheView;

public class CacheImpl implements Cache, CacheView {

	private final Map<String, Object> cache;
	private final int cacheMaxSize;

	public CacheImpl(int cacheMaxSize) {
		super();
		this.cacheMaxSize = cacheMaxSize;
		// We use LinkedHashMap implementation, because order for insert element is important
		this.cache = new LinkedHashMap<>(cacheMaxSize);
	}

	@Override
	public CacheItem cacheItem(Object item, String key) {
		boolean isCacheMaxSizeExceeded = getView().size() == cacheMaxSize;
		if (isCacheMaxSizeExceeded) {
			CacheItem oldestCachedElement = getItem(0);
			cache.remove(oldestCachedElement.getKey());
		}
		cache.put(key, item);
		return new CacheItemImpl(key, item);
	}

	@Override
	public CacheItem getItem(int index) {

		//	Order is guaranteed
		//	https://stackoverflow.com/questions/1190083/does-entryset-in-a-linkedhashmap-also-guarantee-order

		List<Entry<String, Object>> entries = new ArrayList<>(cache.entrySet());
		Entry<String, Object> entry = entries.get(index);

		boolean notExistingValue = entry == null;
		return notExistingValue ? null : new CacheItemImpl(entry.getKey(), entry.getValue());
	}

	@Override
	public CacheItem getItem(String key) {
		Object item = cache.get(key);
		boolean notExistingValue = item == null;
		return notExistingValue ? null : new CacheItemImpl(key, item);
	}

	@Override
	public Collection<Object> getValues() {
		return cache.values();
	}

	@Override
	public CacheView getView() {
		return this;
	}

	@Override
	public void invalidateCache() {
		cache.clear();
	}

	@Override
	public int size() {
		return cache.size();
	}

	@Override
	public String toString() {
		return cache.toString();
	}

}
